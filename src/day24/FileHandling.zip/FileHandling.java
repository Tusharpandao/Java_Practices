package day24;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileHandling {

    static File file = new File("Demo.txt");
    static boolean isRunning = true;

    public static void main(String[] args) {

        while (isRunning) {

            System.out.println("Menu");
            System.out.println("1. Create File");
            System.out.println("2. Write to File");
            System.out.println("3. Read File");
            System.out.println("4. delete file");
            System.out.println("5. Exit");
            System.out.println("Enter your choice");
            Scanner scanner = new Scanner(System.in);
            int choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    createFile();
                    break;
                case 2:
                    try {
                        writeFile();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    break;
                case 3:
                    try {
                        readFile();
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                    break;
                case 4:
                    deleteFile();
                    break;
                case 5:
                    isRunning = false;
                    break;
                default:
                    System.out.println("Invalid choice Try again");
                    break;
            }

        }

    }

    private static void createFile() {

        if (file.exists()) {
            System.out.println("File already exists");

        } else {
            try {
                file.createNewFile();
                System.out.println("File Created");
            } catch (IOException e) {
                e.printStackTrace();
                System.out.println("File not created");
            }

        }

    }

    private static void writeFile() throws IOException {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the data to write to the file");
        String data = scanner.nextLine();
        if (file.exists()) {

            FileWriter fileWriter = new FileWriter(file);

            fileWriter.write(data);
            System.out.println("data written to the  file");
            fileWriter.close();
        } else {
            file.createNewFile();

            FileWriter fileWriter = new FileWriter(file);

            fileWriter.write(data);
            System.out.println("data written to the  file");
            fileWriter.close();
        }
    }

    private static void deleteFile() {
        if (file.exists()) {
            file.delete();
            System.out.println("File deleted");
        } else {
            System.out.println("File does not exist");
        }
    }

    private static void readFile() throws FileNotFoundException {
        if (file.exists()) {

            Scanner scanner = new Scanner(file);

            System.out.println("File content : ");
            while (scanner.hasNextLine()) {
                System.out.println(scanner.nextLine());
            }
            scanner.close();
        } else {
            System.out.println("file does not exist");
        }
    }

    private static void getInformationAboutFile() {
        if (file.exists()) {
            System.out.println("File name: " + file.getName());
            System.out.println("File path: " + file.getAbsolutePath());
            System.out.println("File size: " + file.length());
            System.out.println("File is readable: " + file.canRead());
            System.out.println("File is writable: " + file.canWrite());
            System.out.println("File is executable: " + file.canExecute());
            System.out.println("File is hidden: " + file.isHidden());
            System.out.println("File is directory: " + file.isDirectory());
            System.out.println("File is file: " + file.isFile());
            System.out.println("File is absolute: " + file.isAbsolute());
            System.out.println("File is hidden: " + file.isHidden());
            System.out.println("File is hidden: " + file.isHidden());
            System.out.println("File is hidden: " + file.isHidden());

        }

    }

}
